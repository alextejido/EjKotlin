package org.jetbrains.android.anko.utils

class KVariable(val name: String, val type: KType)