linearLayout {
    orientation = LinearLayout.VERTICAL

    textView("Hello World").lparams(width = matchParent, height = wrapContent)
}